document.addEventListener("DOMContentLoaded", function () {
  const addBtn = document.getElementById("add-btn");
  const taskInput = document.getElementById("task-input");
  const taskList = document.getElementById("task-list");

  let editIndex = null;

  function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    taskList.innerHTML = "";
    tasks.forEach((task, index) => {
      const li = document.createElement("li");
      if (task.done) li.classList.add("checked");

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = task.done;
      checkbox.addEventListener("change", () => {
        tasks[index].done = checkbox.checked;
        saveTasks(tasks);
      });

      const span = document.createElement("span");
      span.textContent = task.text;

      const editBtn = document.createElement("button");
      editBtn.textContent = "✏️";
      editBtn.style.marginRight = "10px";
      editBtn.addEventListener("click", () => {
        taskInput.value = task.text;
        editIndex = index;
        addBtn.textContent = "UPDATE";
      });

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "✕";
      deleteBtn.addEventListener("click", () => {
        tasks.splice(index, 1);
        saveTasks(tasks);
        resetForm();
      });

      li.appendChild(checkbox);
      li.appendChild(span);
      li.appendChild(editBtn);
      li.appendChild(deleteBtn);
      taskList.appendChild(li);
    });
  }

  function saveTasks(tasks) {
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
  }

  function resetForm() {
    taskInput.value = "";
    addBtn.textContent = "ADD";
    editIndex = null;
  }

  addBtn.addEventListener("click", () => {
    const text = taskInput.value.trim();
    if (!text) return;

    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

    if (editIndex !== null) {
      tasks[editIndex].text = text;
    } else {
      tasks.push({ text, done: false });
    }

    saveTasks(tasks);
    resetForm();
  });

  loadTasks();
});