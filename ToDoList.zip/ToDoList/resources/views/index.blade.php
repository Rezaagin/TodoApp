<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>To-Do List</title>
  <link rel="stylesheet" href="{{ asset('css/style.css') }}">
  <style>
    /* Tambahan gaya langsung di sini (jika tidak pakai file terpisah) */
    .app-title {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      font-size: 32px;
      font-weight: 700;
      color: #4A00E0;
      text-align: center;
      margin-bottom: 10px;
      background: linear-gradient(to right, #8E2DE2, #4A00E0);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: 1px;
    }
  </style>
</head>
<body>
  <div class="todo-container">
    <h1 class="app-title">Aplikasi Kegiatan Harian </h1> <!-- Tambahan judul -->
    <h2>Selamat Datang 📝</h2>
    <div class="input-section">
      <input type="text" id="task-input" placeholder="Add your task">
      <button id="add-btn">ADD</button>
    </div>
    <ul id="task-list"></ul>
  </div>
  <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
